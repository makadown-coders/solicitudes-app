// src/app/features/dashboard-abasto/resumen/resumen.component.ts
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { ChartConfiguration, ChartOptions } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { NgSelectModule } from '@ng-select/ng-select';
import { Cita } from '../../../models/Cita';
import { StorageVariables } from '../../../shared/storage-variables';
import { PeriodoPickerDasboardComponent } from '../../../shared/periodo-picker/periodo-picker-dashboard.component';
import { PeriodoFechasService } from '../../../shared/periodo-fechas.service';
import { FormsModule } from '@angular/forms';
import { CitaFilterService } from '../../../shared/cita-filter.service';
import { FiltrosCita } from '../../../models/filtros-cita';
import { CitaChartService } from '../../../shared/cita-chart.service';
import { CumplimientoTimes, KPIsResumen, SubtotalEstatus, SubtotalTipoEntrega } from '../../../models/StatsCitas';
import { DashboardService } from '../../../services/dashboard.service';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-resumen',
  standalone: true,
  imports: [CommonModule,
    FormsModule, BaseChartDirective, PeriodoPickerDasboardComponent,
    NgSelectModule,],
  templateUrl: './resumen.component.html',
  styleUrl: './resumen.component.css'
})
export class ResumenComponent implements OnInit, OnDestroy {
  cdRef = inject(ChangeDetectorRef);
  private destroy$ = new Subject<void>();
  private citas: Cita[] = [];
  // Opciones de filtros
  aniosDisponibles: number[] = [];
  // Opciones de filtros con mis ajustes de mayúsculas
  estatusDisponibles: string[] = ['COMPLETO', 'INCOMPLETO', 'NO RECIBIR', 'VIGENTE'];
  tipoEntregaDisponibles: string[] = ['ENTREGA DIRECTA', 'OPERADOR LOGÍSTICO'];
  tiposCompraDisponibles: string[] = ['2024C', 'Bianual 25-26', 'Blancos', 'Bianual', 'BMX2', 'Alpha',
    'Ropa Quirúrgica', 'BMX', 'Bianual 23-24', 'Zeta', 'BMX3', 'BMX1'];
  kpisServer: KPIsResumen | null = null;
  subEstatusServer: SubtotalEstatus[] = [];
  subTipoServer: SubtotalTipoEntrega[] = [];
  cumplimientoServer: CumplimientoTimes | null = null;

  constructor(
    private dash: DashboardService,   // 👈 inyectamos
  ) { }
  
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  // Lo que el usuario seleccione
  filtrosSeleccionados = {
    anios: [] as number[],
    estatus: [] as string[],
    tipoEntrega: [] as string[],
    tipoCompra: [] as string[],
  };

  totalPiezas = 0;
  totalOrdenes = 0;
  totalHospitales = 0;
  totalPiezasEmitidas = 0;
  totalPiezasRecibidas = 0;
  porcentajeRecibidoVsEmitido = 0;
  totalEntregasEnFecha = 0;
  totalEntregasAtrasadas = 0;
  porcentajeCumplimiento = 0;
  totalOrdenesCompletas = 0;
  totalOrdenesIncompletas = 0;

  topProveedoresIncumplidos: {
    nombre: string;
    total: number;
    atrasos: number;
    porcentaje: number;
  }[] = [];

  topProveedoresCumplidos: {
    nombre: string;
    total: number;
    aTiempo: number;
    porcentaje: number;
    tiempoPromedioEntrega?: number;
  }[] = [];

  topTiemposPromedioEntregaProveedor: {
    proveedor: string;
    promedio: number;
  }[] = [];

  stackedBarData: ChartConfiguration<'bar'>['data'] = { labels: [], datasets: [] };
  stackedBarOptions: ChartOptions<'bar'> = {
    responsive: true,
    plugins: {
      legend: { position: 'top' },
      tooltip: {
        callbacks: {
          label: (ctx) => `${ctx.dataset.label}: ${ctx.raw} entregas`
        }
      }
    },
    scales: {
      x: { stacked: true },
      y: {
        stacked: true,
        beginAtZero: true,
        ticks: { source: 'labels', count: 1000 }
      }
    }
  };

  barChartData: ChartConfiguration<'bar'>['data'] = { labels: [], datasets: [] };
  public barChartOptions: ChartOptions<'bar'> = {
    responsive: true,
    indexAxis: 'y', // 👈 Hace que las unidades sean el eje Y y las barras crezcan horizontalmente
    plugins: {
      legend: {
        position: 'top',
        labels: {
          color: '#006341', // Color verde para los labels del gráfico
        }
      },
      tooltip: {
        callbacks: {
          label: function (context) {
            const label = context.dataset.label || '';
            const value = context.parsed.x || 0;
            return `${label}: ${value.toLocaleString()}`;
          }
        }
      }
    },
    scales: {
      x: {
        beginAtZero: true,
        // stacked: true,
        ticks: {
          color: '#2E8B57',
          precision: 0,
          source: 'labels', count: 1000
        },
        grid: {
          color: '#e0e0e0',
        }
      },
      y: {
        //stacked: true,
        ticks: {
          color: '#2E8B57',
          source: 'labels', count: 1000
        },
        grid: {
          color: '#f0f0f0',
        }
      }
    }
  };
  lineChartData: ChartConfiguration<'line'>['data'] = { labels: [], datasets: [] };

  fechaInicio: Date = new Date();
  fechaFin: Date = new Date();

  citaFilterService = inject(CitaFilterService);
  citaChartService = inject(CitaChartService);
  fechasService = inject(PeriodoFechasService);

  ngOnInit(): void {
    const compras = new Set(this.citas.map(c => c.compra).filter(Boolean));
    if (compras.size > 0) {
      this.tiposCompraDisponibles = Array.from(compras).sort();
    }

    const tentregas = new Set(this.citas.map(c => c.tipo_de_entrega).filter(Boolean));
    if (tentregas.size > 0) {
      this.tipoEntregaDisponibles = Array.from(tentregas).sort();
    }

    this.cargarFechasIniciales();
    this.generarAniosDisponibles();

    //this.calcularDatos();

    // 🔹 SUSCRIPCIÓN: cada vez que el server devuelva citas filtradas, recalculamos todo
    this.dash.resumenCitas$.pipe(takeUntil(this.destroy$)).subscribe((list) => {
      this.citas = list ?? [];
      // refresca catálogos dependientes (por si cambiaron con filtros)
      const compras2 = new Set(this.citas.map(c => c.compra).filter(Boolean));
      if (compras2.size > 0) this.tiposCompraDisponibles = Array.from(compras2).sort();

      const tentregas2 = new Set(this.citas.map(c => c.tipo_de_entrega).filter(Boolean));
      if (tentregas2.size > 0) this.tipoEntregaDisponibles = Array.from(tentregas2).sort();

      this.generarAniosDisponibles(); // por si el set de años cambia con filtros
      this.calcularDatosCon(this.citas); // 👈 nueva función (ver abajo)

      this.cdRef.markForCheck();
    });

    // 👇 suscripción a stats del server
    this.dash.kpis$.pipe(takeUntil(this.destroy$)).subscribe(k => {
      this.kpisServer = k;
      this.cdRef.markForCheck();  // 👈 fuerza re-render OnPush
    });

    // Primera corrida: propaga filtros actuales y dispara carga al server
    this.propagateFiltersToServer();
    this.dash.recargarResumen();
  }

  private toISO(d: Date | null | undefined) {
    return d ? new Date(d).toISOString().slice(0, 10) : undefined;
  }

  private normalizeTipoEntregaForDB(v: string): string {
    // tus UI usan mayúsculas “ENTREGA DIRECTA / OPERADOR LOGÍSTICO”
    // en BD tienes “Entrega directa” y “Operador Logístico” (según limpieza que hiciste).
    const s = (v || '').trim().toUpperCase();
    if (s.includes('OPERADOR')) return 'Operador Logístico';
    if (s.includes('ENTREGA')) return 'Entrega directa';
    return v;
  }

  private propagateFiltersToServer() {
    // año (si hay múltiples, toma el primero por ahora)
    if (this.filtrosSeleccionados.anios?.length) {
      this.dash.setFiltroEjercicio(this.filtrosSeleccionados.anios);
    } else {
      // Limpia ejercicio si no hay selección
      this.dash.setFiltroEjercicio(undefined as any);
    }

    // estatus exacto (por ahora toma 1º si hay varios)
    this.dash.setFiltroEstatus(
      (this.filtrosSeleccionados.estatus ?? []).map(s => s.toUpperCase())
    );

    // tipo de entrega (normalizado a texto BD)
    this.dash.setFiltroTipoEntrega(
      (this.filtrosSeleccionados.tipoEntrega ?? []).map(this.normalizeTipoEntregaForDB)
    );

    // compra (exacto)
    this.dash.setFiltroCompra(
      (this.filtrosSeleccionados.tipoCompra ?? []).map(s => s.toUpperCase())
    );

    // rango de fechas → usa fecha_recepcion_min/max del lado server
    this.dash.setRangoFechas(this.toISO(this.fechaInicio), this.toISO(this.fechaFin));
  }

  generarAniosDisponibles() {
    const aniosSet = new Set<number>();
    this.citas.forEach(c => {
      if (c.ejercicio != null) {
        aniosSet.add(c.ejercicio);
      }
    });
    this.aniosDisponibles = Array.from(aniosSet).sort((a, b) => a - b);
    // si aniosDisponibles esta vacio, generar lista de este año y el anterior
    if (this.aniosDisponibles.length === 0) {
      this.aniosDisponibles = [new Date().getFullYear(), new Date().getFullYear() - 1];
      // si estamos a 2026+, agregar otro año anterior al anterior
      if (new Date().getFullYear() >= 2026) {
        this.aniosDisponibles.unshift(new Date().getFullYear() - 2);
      }
    }
  }

  cargarFechasIniciales() {
    const inicio = localStorage.getItem(StorageVariables.DASH_ABASTO_RESUMEN_FECHA_INICIO);
    const fin = localStorage.getItem(StorageVariables.DASH_ABASTO_RESUMEN_FECHA_FIN);
    // obtener los anios, estatus y tipos de entrega de localStorage
    this.filtrosSeleccionados.anios = JSON.parse(localStorage.getItem(StorageVariables.DASH_ABASTO_RESUMEN_ANIOS) || '[]');
    this.filtrosSeleccionados.estatus = JSON.parse(localStorage.getItem(StorageVariables.DASH_ABASTO_RESUMEN_ESTATUS) || '[]');
    this.filtrosSeleccionados.tipoEntrega = JSON.parse(localStorage.getItem(StorageVariables.DASH_ABASTO_RESUMEN_TIPOS_ENTREGA) || '[]');
    this.filtrosSeleccionados.tipoCompra = JSON.parse(localStorage.getItem(StorageVariables.DASH_ABASTO_RESUMEN_COMPRAS) || '[]');

    if (inicio && fin) {
      this.fechaInicio = new Date(inicio);
      this.fechaFin = new Date(fin);
    } else {
      const hoy = new Date();
      this.fechaFin = hoy;
      // this.fechaInicio = new Date(hoy.getFullYear(), 0, 1);

      /* OPCIONAL POR SI SE OFRECE:*/
        // calcular this.fechaInicio como this.fechaFin menos 90 dias
      const d90 = 90 * 24 * 60 * 60 * 1000;
      this.fechaInicio = new Date(hoy.getTime() - d90); 
    }
  }

  calcularDatosCon(citasFuente: Cita[]) {
    localStorage.setItem(StorageVariables.DASH_ABASTO_RESUMEN_ANIOS, JSON.stringify(this.filtrosSeleccionados.anios));
    localStorage.setItem(StorageVariables.DASH_ABASTO_RESUMEN_ESTATUS, JSON.stringify(this.filtrosSeleccionados.estatus));
    localStorage.setItem(StorageVariables.DASH_ABASTO_RESUMEN_TIPOS_ENTREGA, JSON.stringify(this.filtrosSeleccionados.tipoEntrega));
    localStorage.setItem(StorageVariables.DASH_ABASTO_RESUMEN_COMPRAS, JSON.stringify(this.filtrosSeleccionados.tipoCompra));
/*
    const filtros: FiltrosCita = {
      fechaInicio: this.fechaInicio,
      fechaFin: this.fechaFin,
      anios: this.filtrosSeleccionados.anios,
      estatus: this.filtrosSeleccionados.estatus ? this.filtrosSeleccionados.estatus.map(e => e.toUpperCase()) : [],
      tipoEntrega: this.filtrosSeleccionados.tipoEntrega ? this.filtrosSeleccionados.tipoEntrega.map(e => e.toUpperCase()) : [],
      tipoCompra: (this.filtrosSeleccionados.tipoCompra ?? []),
    };*/
    // hacer un map de unidades con clues_destino para apoyo en caso de detectar citas sin unidad
    const mapaUnidades = new Map<string, string>();
    citasFuente.forEach(c => {
      if (c.unidad && c.clues_destino) {
        mapaUnidades.set(c.clues_destino, c.unidad);
      }
    });

    // mostrar en consola los nombres de cada unidad (distinct)
    citasFuente.forEach(c => {
      if (!c.unidad || c.unidad.trim().length === 0) {
        // console.warn(`Cita sin unidad: CluesDestino=${c.clues_destino}, Orden=${c.orden_de_suministro}`);
        // obtenemos unidad del mapa
        const unidadMapa = mapaUnidades.get(c.clues_destino);
        if (unidadMapa) {
          c.unidad = unidadMapa;
          // console.info(`  → asignada unidad desde mapa: ${unidadMapa}`);
        }
      }
    });

    const citasFiltradas = citasFuente.filter(c => c.unidad != null && c.unidad.length > 0);  //this.citaFilterService.filtrar(citasFuente, filtros);

    this.obtenerKPIs(citasFiltradas);
    // Gráficas
    this.barChartData = this.citaChartService.obtenerPiezasPorUnidad(citasFiltradas);
    this.lineChartData = this.citaChartService.obtenerTendenciaDiaria(citasFiltradas);
    this.generarCumplimientoMensualPorBarras(citasFiltradas);
    this.generarTopProveedores(citasFiltradas);
    this.generarTopProveedoresCumplidos(citasFiltradas);
    this.generarTopTiemposPromedioEntregaProveedor(citasFiltradas);

    // this.propagateFiltersToServer();
    // this.dash.cargarStats();
  }

  obtenerKPIs(citasFiltradas: Cita[]) {
    this.totalPiezas = citasFiltradas.reduce((sum, c) => sum + (c.pzas_recibidas_por_la_entidad || 0), 0);
    this.totalOrdenes = new Set(citasFiltradas.map(c => c.orden_de_suministro)).size;
    this.totalHospitales = new Set(citasFiltradas.map(c => c.unidad)).size;
    // Total órdenes distintas ya se calcula, ahora contamos las vigentes
    const ordenesVigentes = new Set<string>();
    this.totalPiezasEmitidas = 0;
    this.totalEntregasEnFecha = 0;
    this.totalEntregasAtrasadas = 0;
    this.totalOrdenesCompletas = 0;
    this.totalOrdenesIncompletas = 0;

    const mapaOrdenes: Map<string, { recibidas: number; emitidas: number }> = new Map();

    for (const cita of citasFiltradas) {
      const orden = cita.orden_de_suministro;
      if (!orden) continue;

      // 1. completas e incompletas
      const actuales = mapaOrdenes.get(orden) || { recibidas: 0, emitidas: 0 };
      actuales.recibidas += cita.pzas_recibidas_por_la_entidad || 0;
      actuales.emitidas += cita.no_de_piezas_emitidas || 0;
      mapaOrdenes.set(orden, actuales);

      // 2. Piezas emitidas
      this.totalPiezasEmitidas += cita.no_de_piezas_emitidas || 0;
      this.totalPiezasRecibidas += cita.pzas_recibidas_por_la_entidad || 0;

      // 3. Cumplimiento de plazo
      if (cita.fecha_limite_de_entrega && cita.fecha_recepcion_almacen) {
        const fLimite = new Date(cita.fecha_limite_de_entrega);
        const fRecepcion = new Date(cita.fecha_recepcion_almacen);
        if (fRecepcion <= fLimite) {
          this.totalEntregasEnFecha++;
        } else {
          this.totalEntregasAtrasadas++;
        }
      }
    }

    // Guardamos resultado de completas vs incompletas
    mapaOrdenes.forEach(({ recibidas, emitidas }) => {
      if (recibidas >= emitidas) {
        this.totalOrdenesCompletas++;
      } else {
        this.totalOrdenesIncompletas++;
      }
    });

    // Porcentaje de piezas recibidas vs emitidas
    this.porcentajeRecibidoVsEmitido = this.totalPiezasEmitidas > 0
      ? (this.totalPiezas / this.totalPiezasEmitidas) * 100
      : 0;

    // Porcentaje de cumplimiento de plazo
    const totalEntregas = this.totalEntregasEnFecha + this.totalEntregasAtrasadas;
    this.porcentajeCumplimiento = totalEntregas > 0
      ? (this.totalEntregasEnFecha / totalEntregas) * 100
      : 0;
  }

  onFiltrosChanged() {
    this.propagateFiltersToServer();
    // Dispara ambos: KPIs + lista
    this.dash.recargarResumen();
    // No recalcules aquí: espera a la llegada de citas del server (suscripción arriba)
  }

  onPeriodoSeleccionado(event: { texto: string, fechaInicio: Date, fechaFin: Date }) {
    this.fechaInicio = event.fechaInicio;
    this.fechaFin = event.fechaFin;

    localStorage.setItem(StorageVariables.DASH_ABASTO_RESUMEN_FECHA_INICIO, this.fechaInicio.toISOString());
    localStorage.setItem(StorageVariables.DASH_ABASTO_RESUMEN_FECHA_FIN, this.fechaFin.toISOString());

    this.onFiltrosChanged();
  }

  generarTopProveedores(citas: Cita[]) {
    const resumen = new Map<string, { total: number; atrasos: number }>();

    for (const cita of citas) {
      const proveedor = cita.proveedor || 'SIN PROVEEDOR';
      const total = resumen.get(proveedor) || { total: 0, atrasos: 0 };
      total.total++;
      if (cita.fecha_limite_de_entrega && cita.fecha_recepcion_almacen) {
        const f1 = new Date(cita.fecha_limite_de_entrega);
        const f2 = new Date(cita.fecha_recepcion_almacen);
        if (f2 > f1) total.atrasos++;
      }
      resumen.set(proveedor, total);
    }

    const lista = Array.from(resumen.entries()).map(([nombre, { total, atrasos }]) => ({
      nombre,
      total,
      atrasos,
      porcentaje: total > 0 ? ((total - atrasos) / total) * 100 : 0
    }));

    this.topProveedoresIncumplidos = lista
      .filter(p => p.total > 3 && p.atrasos > 0) // Umbral
      .sort((a, b) => b.atrasos - a.atrasos)
      .slice(0, 15)
      .sort((a, b) => a.porcentaje - b.porcentaje);
  }

  generarCumplimientoMensualPorBarras(citas: Cita[]) {
    const meses = [
      'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
      'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ];

    const entregasPorMes = Array(12).fill(null).map(() => ({
      enFecha: 0,
      atrasadas: 0
    }));

    for (const cita of citas) {
      if (!cita.fecha_recepcion_almacen || !cita.fecha_limite_de_entrega) continue;

      const fRecepcion = new Date(cita.fecha_recepcion_almacen);
      const fLimite = new Date(cita.fecha_limite_de_entrega);
      const mes = fRecepcion.getMonth();

      entregasPorMes[mes] = entregasPorMes[mes] || { enFecha: 0, atrasadas: 0 };
      if (fRecepcion <= fLimite) {
        entregasPorMes[mes].enFecha++;
      } else {
        entregasPorMes[mes].atrasadas++;
      }
    }

    this.stackedBarData = {
      labels: meses,
      datasets: [
        {
          label: 'Entregas a tiempo',
          data: entregasPorMes.map(m => m.enFecha),
          backgroundColor: '#2E8B57'
        },
        {
          label: 'Entregas atrasadas',
          data: entregasPorMes.map(m => m.atrasadas),
          backgroundColor: '#e74c3c'
        }
      ]
    };
  }

  generarTopProveedoresCumplidos(citas: Cita[]) {
    const resumen = new Map<string, { total: number; aTiempo: number }>();

    for (const cita of citas) {
      const proveedor = cita.proveedor || 'SIN PROVEEDOR';
      const actual = resumen.get(proveedor) || { total: 0, aTiempo: 0 };
      actual.total++;

      if (cita.fecha_limite_de_entrega && cita.fecha_recepcion_almacen) {
        const fRecepcion = new Date(cita.fecha_recepcion_almacen);
        const fLimite = new Date(cita.fecha_limite_de_entrega);
        if (fRecepcion <= fLimite) {
          actual.aTiempo++;
        }
      }
      resumen.set(proveedor, actual);
    }

    const lista = Array.from(resumen.entries()).map(([nombre, { total, aTiempo }]) => ({
      nombre,
      total,
      aTiempo,
      porcentaje: total > 0 ? (aTiempo / total) * 100 : 0
    }));

    const preCumplidos = lista.sort((a, b) => b.porcentaje - a.porcentaje);
    this.topProveedoresCumplidos = preCumplidos
      .filter(p => p.total > 0 && p.porcentaje >= 90)
      .slice(0, 15)
      .sort((a, b) => b.aTiempo - a.aTiempo);

    this.topProveedoresCumplidos.forEach((p) => {
      p.tiempoPromedioEntrega = Math.abs(this.diasPromedioEntregaProveedor(p.nombre, citas));
    });
  }

  diasPromedioEntregaProveedor(nombre: string, citas: Cita[]): number {
    const citasFiltradas = citas.filter(c => c.proveedor === nombre);
    let diasPromedio = 0;
    for (const cita of citasFiltradas) {
      if (cita.fecha_emision && cita.fecha_recepcion_almacen) {
        const fechasRecepcion = cita.fecha_recepcion_almacen
          .split('/')
          .map((f) => this.fechasService.parseLocalDate(f));

        fechasRecepcion.forEach(fRecepcion => {
          const fEmision = new Date(cita.fecha_emision);  //this.fechasService.parseLocalDate(cita.fecha_emision + '');
          const diferencia = fRecepcion.getTime() - fEmision.getTime();
          diasPromedio += diferencia;
        });
      }
    }
    return this.convertMilliseconds(diasPromedio / citasFiltradas.length).days;
  }

  generarTopTiemposPromedioEntregaProveedor(citasFiltradas: Cita[]) {
    const resumen = new Map<string, { total: number; promedio: number }>();

    for (const cita of citasFiltradas) {
      const proveedor = cita.proveedor || 'SIN PROVEEDOR';
      const actual = resumen.get(proveedor) || { total: 0, promedio: 0 };

      if (cita.fecha_emision && cita.fecha_recepcion_almacen) {
        actual.total++;
          const fEmision = new Date(cita.fecha_emision); // this.fechasService.parseLocalDate(cita.fecha_emision + '');
          const fRecepcion = new Date(cita.fecha_recepcion_almacen);
          const diferencia = fRecepcion.getTime() - fEmision.getTime();
          actual.promedio += diferencia;
        /*
        // seccion de codigo por deprecar, ya que la fecha de recepcion ahora es unica (la minima)
        const fechasRecepcion = cita.fecha_recepcion_almacen
          .split('/')
          .map((f) => this.fechasService.parseLocalDate(f));

        fechasRecepcion.forEach(fRecepcion => {
          actual.total++;
          const fEmision = this.fechasService.parseLocalDate(cita.fecha_emision + '');
          const diferencia = fRecepcion.getTime() - fEmision.getTime();
          actual.promedio += diferencia;
        });*/
      }
      resumen.set(proveedor, actual);
    }

    const lista = Array.from(resumen.entries()).map(([proveedor, { total, promedio }]) => ({
      proveedor,
      total,
      promedio: promedio / total
    }));

    this.topTiemposPromedioEntregaProveedor = [];
    const promedios = lista
      .filter(p => p.total > 0)
      .sort((a, b) => a.promedio - b.promedio)
      .slice(0, 15);

    /*  // peores promedios
    const promedios = lista
      .filter(p => p.total > 0)
      .sort((a, b) => b.promedio - a.promedio)
      .slice(0, 15);*/

    promedios.forEach(p => this.topTiemposPromedioEntregaProveedor
      .push({ proveedor: p.proveedor, promedio: p.promedio })
    );
  }

  convertMilliseconds(ms: number) {
    const days = Math.floor(ms / (24 * 60 * 60 * 1000));
    const daysMs = ms % (24 * 60 * 60 * 1000);
    const hours = Math.floor(daysMs / (60 * 60 * 1000));
    const hoursMs = daysMs % (60 * 60 * 1000);
    const minutes = Math.floor(hoursMs / (60 * 1000));

    return { days, hours, minutes };
  }

}
