export type TemporalExistenciaRow = {
  fuente: 'SAS'|'SALUS';
  alias_sas?: string | null;
  cluessa?: string | null;
  cluesimb?: string | null;
  clave_cnis: string;
  lote?: string | null;
  fecha_caducidad?: string | null; // 'YYYY-MM-DD' o null
  existencia: number;
};
